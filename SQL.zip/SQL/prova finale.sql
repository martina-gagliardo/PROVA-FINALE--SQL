create database ToysGroup;


use ToysGroup;
create table Product (
Productid int primary key not null,
Name Varchar(100),
Category Varchar(100)
);

Create table Region (
Regionid int primary key not null,
Name Varchar(100),
Country Varchar(100)
);

Create table Sales (
Salesid int primary key not null,
Salesdate date,
Price decimal(10,2),
Quantity Int,
Productid int,
Regionid int,
Foreign key (Productid) references Product(Productid),
Foreign key (Regionid) references Region(Regionid)

);




insert into Product VALUES
(1, 'mattoncini', 'costruzioni'),
(2, 'peluche', 'pupazzi'),
(3, 'puzzle disney', 'puzzle'),
(4, 'pistola ad acqua' , 'giochi all aperto'),
(5, 'cubo di rubik', 'Rompicapo'),
(6, 'paperelle da bagno' , 'giochi infanzia'),
(7, 'secchiello con paletta', 'giochi da spiaggia');

insert into Region Values 
(1, 'California', 'USA'),
(2, 'Baviera', 'Germania'),
(3, 'Île-de-France', 'Francia'),
(4, 'Kanto', 'Giappone'),
(5, 'Nuovo Galles del Sud', 'Australia'),
(6, 'Ontario', 'Canada'),
(7, 'São Paulo', 'Brasile');

insert into Sales -- (Salesid, Salesdate, Price, Quantity, Productid, Regionid)  Values 
(1, '2024-02-15', 14.99, 5, 4, 1),
(2, '2024-01-03', 25.00, 5, 3, 2),
(3, '2024-01-04', 18.00, 20, 4, 4),
(4, '2024-01-05', 12.00, 25, 3, 5),
(5, '2024-01-06', 9.00, 30, 6, 6),
(6, '2024-01-07', 22.00, 8, 7, 4),
(7, '2024-01-08', 17.50, 12, 1, 1),
(8, '2024-01-09', 19.99, 11, 7, 3),
(9, '2024-01-10', 34.99, 6, 3, 4);

-- Verificare che i campi definiti come PK siano univoci

select count(distinct productid) 
from product as p; 

select count(distinct Regionid) 
from region as r;

select count(distinct Salesid)
from Sales as s;

-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno
Select p.name as nome_prodotti, year(salesdate) as anno,
sum(quantity * price) as totale_prodotti_venduti 
from sales as s
inner join Product as p
on p.productid = s.productid 
group by p.name, year(salesdate)

-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente

select r.country as paese, year(s.salesdate) as anno , 
sum(quantity * price) as fatturato_totale
from sales as s 
inner join region as r 
on s.regionid = r.regionid
group by r.country, year(s.salesdate)
order by anno, fatturato_totale desc 

-- Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 

select p.category as categoria
from sales as s 
inner join product as p
on p.productid = s.productid 
order by s.quantity desc 
limit 1;

-- Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 


select p.name as nome_prodotto
from product as p 
left join sales as s  
on p.productid = s.productid 
where s.productid is null  

-- oppure

select p.name as nome_prodotto
from product as p
where p.Productid not in ( select s.Productid
						from sales as s
						where s.productid is not null)


-- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

select s.salesdate as data_vendita, p.name as nome_prodotto
from sales as s
inner join product as p
on p.productid = s.productid 
group by s.salesdate, p.name 
order by salesdate desc
limit 1;









